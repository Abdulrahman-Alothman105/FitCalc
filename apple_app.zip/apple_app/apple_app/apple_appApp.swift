//
//  apple_appApp.swift
//  apple_app
//
//  Created by Mohammed on 14/05/1447 AH.
//

import SwiftUI

@main
struct apple_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
